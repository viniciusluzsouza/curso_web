console.log('a =', a)

var a = 3
console.log('a =', a)

//console.log('b =', b)
let b = 5
console.log('b =', b)